def greet(name):
    return f"Hello, {name}!"

print(greet("Campus"))
