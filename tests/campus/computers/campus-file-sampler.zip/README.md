# Campus OS File Sampler

Open media in Files, orbit the 3D models, edit the source files, and extract mini.zip.
Run code/hello.campus in Terminal with run or ./ when inside its folder. Expected output: 6, 6, 6 on separate lines.
